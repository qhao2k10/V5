package com.lqh.gamegeniex;

import android.Manifest;
import android.app.Activity;
import android.app.Dialog;
import android.app.DownloadManager;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.pm.ResolveInfo;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Environment;
import android.os.Handler;
import android.provider.Settings;
import android.text.InputType;
import android.view.Gravity;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.HorizontalScrollView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Random;

public class MainActivity extends Activity {
    private static final String PREF = "lqh_v5_glitch_pref";
    private static final int REQ_STORAGE = 2026;
    private final Handler handler = new Handler();
    private final Random random = new Random();
    private SharedPreferences sp;
    private TextView selectedText, modeStatus, title, matrixLine, checkText;
    private Button ecoBtn, midBtn, xBtn;
    private boolean pendingOverlayOnly = false;
    private boolean pendingOverlayAndGame = false;

    private final Runnable glitchLoop = new Runnable() {
        @Override public void run() {
            String[] sig = {"0xLQH", "V5", "GENIE", "XHUD", "PING", "RAM", "FPS", "NEON"};
            String pulse = sig[random.nextInt(sig.length)] + " // " + randomHex(4) + " // MODE " + currentModeName();
            if (matrixLine != null) matrixLine.setText("▰ " + pulse + " ▰ " + randomBits(16));
            if (title != null) {
                title.setShadowLayer(18 + random.nextInt(8), random.nextInt(3) - 1, random.nextInt(3) - 1,
                        random.nextBoolean() ? Color.rgb(0, 255, 120) : Color.rgb(255, 23, 68));
            }
            handler.postDelayed(this, 320);
        }
    };

    @Override protected void onCreate(Bundle b) {
        super.onCreate(b);
        sp = getSharedPreferences(PREF, MODE_PRIVATE);
        if (!sp.contains("mode")) sp.edit().putString("mode", "MID").apply();
        buildUi();
        handler.post(glitchLoop);
    }

    @Override protected void onResume() {
        super.onResume();
        if ((pendingOverlayOnly || pendingOverlayAndGame) && canOverlay()) {
            boolean openGame = pendingOverlayAndGame;
            pendingOverlayOnly = false;
            pendingOverlayAndGame = false;
            startHud(openGame);
        }
        updateSelectedText();
        updateModeUi();
    }

    @Override protected void onDestroy() {
        handler.removeCallbacks(glitchLoop);
        super.onDestroy();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(14), dp(16), dp(14), dp(24));
        root.setBackground(new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(0, 0, 0), Color.rgb(4, 0, 8), Color.rgb(0, 18, 14)}));
        scroll.addView(root, new ScrollView.LayoutParams(-1, -2));
        setContentView(scroll);

        TextView badge = text("LQH HACKER GENIE X • V5 GLITCH HUD", 12, Color.rgb(0, 255, 120), true);
        badge.setGravity(Gravity.CENTER);
        badge.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        badge.setPadding(dp(10), dp(7), dp(10), dp(7));
        badge.setBackground(box(Color.rgb(0, 12, 10), Color.rgb(0, 255, 120), 16, 2));
        root.addView(badge, lp(-1, -2, 0, 0, 0, 12));

        title = text("LQH GAME\nGENIE X // V5", 35, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        title.setLetterSpacing(0.03f);
        root.addView(title, lp(-1, -2, 0, 0, 0, 8));

        matrixLine = text("▰ 0xLQH // GLITCH BOOT ▰ 101010", 12, Color.rgb(0, 255, 120), true);
        matrixLine.setGravity(Gravity.CENTER);
        matrixLine.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        matrixLine.setPadding(dp(8), dp(6), dp(8), dp(6));
        matrixLine.setBackground(box(Color.rgb(0, 8, 8), Color.rgb(0, 120, 80), 12, 1));
        root.addView(matrixLine, lp(-1, -2, 0, 0, 0, 14));

        LinearLayout hero = card(Color.rgb(4, 4, 10), Color.rgb(0, 255, 120), 26, 2);
        hero.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.addView(hero, lp(-1, -2, 0, 0, 0, 16));

        modeStatus = text("", 15, Color.WHITE, true);
        modeStatus.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        modeStatus.setGravity(Gravity.CENTER);
        modeStatus.setPadding(dp(10), dp(10), dp(10), dp(10));
        hero.addView(modeStatus, lp(-1, -2, 0, 0, 0, 10));

        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.VERTICAL);
        hero.addView(modes, lp(-1, -2, 0, 0, 0, 10));

        ecoBtn = modeButton("🟢 TIẾT KIỆM", Color.rgb(0, 180, 90));
        ecoBtn.setOnClickListener(v -> setMode("ECO"));
        modes.addView(ecoBtn, lp(-1, dp(50), 0, 0, 0, 8));

        midBtn = modeButton("🟣 TRUNG BÌNH", Color.rgb(120, 80, 255));
        midBtn.setOnClickListener(v -> setMode("MID"));
        modes.addView(midBtn, lp(-1, dp(50), 0, 0, 0, 8));

        xBtn = modeButton("🔴 NÂNG CAO GIỰT FX", Color.rgb(255, 23, 68));
        xBtn.setOnClickListener(v -> setMode("X"));
        modes.addView(xBtn, lp(-1, dp(50), 0, 0, 0, 0));

        selectedText = text("", 14, Color.WHITE, false);
        selectedText.setTypeface(Typeface.MONOSPACE);
        selectedText.setPadding(dp(12), dp(10), dp(12), dp(10));
        selectedText.setBackground(box(Color.rgb(8, 8, 18), Color.rgb(0, 255, 255), 18, 1));
        hero.addView(selectedText, lp(-1, -2, 0, 10, 0, 10));
        updateSelectedText();

        Button test = bigButton("☠ TEST MENU NỔI V5 NGAY", Color.rgb(0, 255, 120), Color.rgb(0, 120, 255));
        test.setOnClickListener(v -> requestHud(false));
        hero.addView(test, lp(-1, dp(58), 0, 0, 0, 10));

        Button start = bigButton("🎮 BẬT HUD GLITCH + VÀO GAME", Color.rgb(255, 23, 68), Color.rgb(255, 170, 0));
        start.setOnClickListener(v -> requestHud(true));
        hero.addView(start, lp(-1, dp(58), 0, 0, 0, 10));

        Button pick = darkButton("CHỌN GAME / APP", Color.rgb(0, 255, 255));
        pick.setOnClickListener(v -> showGamePicker());
        hero.addView(pick, lp(-1, dp(52), 0, 0, 0, 0));

        HorizontalScrollView hsv = new HorizontalScrollView(this);
        hsv.setHorizontalScrollBarEnabled(false);
        LinearLayout strip = new LinearLayout(this);
        strip.setOrientation(LinearLayout.HORIZONTAL);
        hsv.addView(strip);
        root.addView(hsv, lp(-1, -2, 0, 0, 0, 16));
        addChip(strip, "GLITCH HUD");
        addChip(strip, "3 MODE");
        addChip(strip, "RAM MONITOR");
        addChip(strip, "PING PANEL");
        addChip(strip, "NO ROOT");
        addChip(strip, "V5" );

        LinearLayout features = card(Color.rgb(5, 5, 14), Color.rgb(255, 23, 68), 22, 2);
        features.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.addView(features, lp(-1, -2, 0, 0, 0, 16));
        features.addView(text("BẢN NÀY KHÁC BẢN CŨ", 18, Color.rgb(0, 255, 120), true), lp(-1, -2, 0, 0, 0, 8));
        features.addView(text("• Có chữ V5 GLITCH HUD ở đầu app\n• Có 3 chế độ: Tiết kiệm / Trung bình / Nâng cao\n• Menu nổi trong game có nút chọn mode\n• Hiệu ứng giựt màu kiểu hacker/cyber\n• Icon app mới dạng X neon siêu nét", 14, Color.rgb(225, 235, 240), false));

        LinearLayout music = card(Color.rgb(4, 8, 12), Color.rgb(0, 255, 255), 22, 1);
        music.setPadding(dp(14), dp(14), dp(14), dp(14));
        root.addView(music, lp(-1, -2, 0, 0, 0, 16));
        music.addView(text("MUSIC LINK → MP3", 18, Color.WHITE, true), lp(-1, -2, 0, 0, 0, 8));
        EditText url = edit("Dán link audio trực tiếp .mp3/.m4a...");
        music.addView(url, lp(-1, dp(52), 0, 0, 0, 8));
        EditText name = edit("Tên file ví dụ: LQH_V5_music.mp3");
        music.addView(name, lp(-1, dp(52), 0, 0, 0, 8));
        Button dl = darkButton("⬇ TẢI VÀO DOWNLOADS", Color.rgb(0, 255, 120));
        dl.setOnClickListener(v -> download(url.getText().toString().trim(), name.getText().toString().trim()));
        music.addView(dl, lp(-1, dp(52), 0, 0, 0, 0));

        checkText = text("CHECK ĐÚNG BẢN: phải thấy V5 GLITCH HUD + 3 nút mode. Không thấy là bạn vẫn cài nhầm bản cũ.", 14, Color.rgb(255, 238, 88), true);
        checkText.setGravity(Gravity.CENTER);
        checkText.setPadding(dp(12), dp(12), dp(12), dp(12));
        checkText.setBackground(box(Color.rgb(18, 6, 4), Color.rgb(255, 23, 68), 20, 2));
        root.addView(checkText, lp(-1, -2, 0, 0, 0, 0));

        updateModeUi();
    }

    private void setMode(String m) {
        sp.edit().putString("mode", m).apply();
        updateModeUi();
        Toast.makeText(this, "Đã chọn chế độ: " + currentModeName(), Toast.LENGTH_SHORT).show();
    }

    private String currentMode() { return sp.getString("mode", "MID"); }

    private String currentModeName() {
        String m = currentMode();
        if ("ECO".equals(m)) return "TIẾT KIỆM";
        if ("X".equals(m)) return "NÂNG CAO";
        return "TRUNG BÌNH";
    }

    private String currentModeInfo() {
        String m = currentMode();
        if ("ECO".equals(m)) return "TIẾT KIỆM: nhẹ pin, HUD ít giựt, cập nhật chậm hơn";
        if ("X".equals(m)) return "NÂNG CAO: giựt FX mạnh, HUD sáng, cập nhật nhanh";
        return "TRUNG BÌNH: cân bằng giữa mượt, pin và hiệu ứng";
    }

    private void updateModeUi() {
        if (modeStatus != null) {
            modeStatus.setText("MODE ĐANG CHỌN: " + currentModeName() + "\n" + currentModeInfo());
            int stroke = "X".equals(currentMode()) ? Color.rgb(255, 23, 68) : ("ECO".equals(currentMode()) ? Color.rgb(0, 255, 120) : Color.rgb(120, 80, 255));
            modeStatus.setBackground(box(Color.rgb(7, 7, 16), stroke, 18, 2));
        }
        markModeButton(ecoBtn, "ECO".equals(currentMode()), Color.rgb(0, 200, 90));
        markModeButton(midBtn, "MID".equals(currentMode()), Color.rgb(120, 80, 255));
        markModeButton(xBtn, "X".equals(currentMode()), Color.rgb(255, 23, 68));
    }

    private void requestHud(boolean openGame) {
        if (!canOverlay()) {
            pendingOverlayOnly = !openGame;
            pendingOverlayAndGame = openGame;
            Toast.makeText(this, "Bật quyền Hiển thị trên ứng dụng khác cho LQH Game Genie X V5", Toast.LENGTH_LONG).show();
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            return;
        }
        startHud(openGame);
    }

    private boolean canOverlay() {
        return Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
    }

    private void startHud(boolean openGame) {
        Intent i = new Intent(this, HudOverlayService.class);
        i.setAction("SHOW_HUD_V5");
        i.putExtra("game_name", sp.getString("game_name", "Chưa chọn game"));
        i.putExtra("mode", currentMode());
        startService(i);
        Toast.makeText(this, "HUD V5 đang bật: tìm bong bóng LQH X trên màn hình", Toast.LENGTH_LONG).show();
        if (openGame) {
            String pkg = sp.getString("game_pkg", "");
            if (pkg.length() == 0) {
                Toast.makeText(this, "Bạn chưa chọn game. Bấm CHỌN GAME trước.", Toast.LENGTH_LONG).show();
                return;
            }
            selectedText.postDelayed(() -> launchPackage(pkg), 900);
        }
    }

    private void launchPackage(String pkg) {
        Intent launch = getPackageManager().getLaunchIntentForPackage(pkg);
        if (launch == null) {
            Toast.makeText(this, "Không mở được game đã chọn", Toast.LENGTH_LONG).show();
            return;
        }
        launch.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        startActivity(launch);
    }

    private void updateSelectedText() {
        if (selectedText == null) return;
        String name = sp.getString("game_name", "Chưa chọn game");
        String pkg = sp.getString("game_pkg", "");
        selectedText.setText("GAME TARGET\n" + name + (pkg.length() > 0 ? "\n" + pkg : "\nBấm CHỌN GAME để chọn app/game."));
    }

    private void showGamePicker() {
        PackageManager pm = getPackageManager();
        Intent main = new Intent(Intent.ACTION_MAIN, null);
        main.addCategory(Intent.CATEGORY_LAUNCHER);
        List<ResolveInfo> all = pm.queryIntentActivities(main, 0);
        List<ResolveInfo> apps = new ArrayList<>();
        for (ResolveInfo r : all) if (!r.activityInfo.packageName.equals(getPackageName())) apps.add(r);
        Collections.sort(apps, new Comparator<ResolveInfo>() {
            @Override public int compare(ResolveInfo a, ResolveInfo b) {
                return String.CASE_INSENSITIVE_ORDER.compare(a.loadLabel(pm).toString(), b.loadLabel(pm).toString());
            }
        });

        Dialog d = new Dialog(this);
        d.requestWindowFeature(Window.FEATURE_NO_TITLE);
        LinearLayout box = new LinearLayout(this);
        box.setOrientation(LinearLayout.VERTICAL);
        box.setPadding(dp(14), dp(14), dp(14), dp(14));
        box.setBackground(box(Color.rgb(3, 3, 8), Color.rgb(0, 255, 120), 24, 2));
        TextView t = text("CHỌN GAME / APP", 20, Color.WHITE, true);
        t.setGravity(Gravity.CENTER);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        box.addView(t, lp(-1, -2, 0, 0, 0, 8));
        ScrollView sv = new ScrollView(this);
        LinearLayout list = new LinearLayout(this);
        list.setOrientation(LinearLayout.VERTICAL);
        sv.addView(list);
        for (ResolveInfo r : apps) {
            String label = r.loadLabel(pm).toString();
            String pkg = r.activityInfo.packageName;
            TextView row = text((isLikelyGame(label, pkg) ? "🎮 " : "▸ ") + label + "\n" + pkg, 15, Color.WHITE, false);
            row.setTypeface(Typeface.MONOSPACE);
            row.setPadding(dp(12), dp(10), dp(12), dp(10));
            row.setBackground(box(Color.rgb(9, 10, 18), isLikelyGame(label, pkg) ? Color.rgb(255, 23, 68) : Color.rgb(0, 120, 120), 18, 1));
            row.setOnClickListener(v -> {
                sp.edit().putString("game_name", label).putString("game_pkg", pkg).apply();
                updateSelectedText();
                Toast.makeText(this, "Đã chọn: " + label, Toast.LENGTH_SHORT).show();
                d.dismiss();
            });
            list.addView(row, lp(-1, -2, 0, 0, 0, 8));
        }
        box.addView(sv, lp(-1, dp(520), 0, 0, 0, 0));
        d.setContentView(box);
        d.show();
        Window win = d.getWindow();
        if (win != null) {
            win.setLayout(WindowManager.LayoutParams.MATCH_PARENT, WindowManager.LayoutParams.WRAP_CONTENT);
            win.setBackgroundDrawableResource(android.R.color.transparent);
        }
    }

    private boolean isLikelyGame(String label, String pkg) {
        String s = (label + " " + pkg).toLowerCase(Locale.US);
        return s.contains("game") || s.contains("garena") || s.contains("freefire") || s.contains("pubg") || s.contains("mobilelegends") || s.contains("roblox") || s.contains("minecraft") || s.contains("genshin") || s.contains("mihoyo") || s.contains("lienquan") || s.contains("arena") || s.contains("valorant");
    }

    private void download(String url, String filename) {
        if (url.length() < 8 || !(url.startsWith("http://") || url.startsWith("https://"))) {
            Toast.makeText(this, "Link phải bắt đầu bằng http:// hoặc https://", Toast.LENGTH_LONG).show();
            return;
        }
        if (filename.length() == 0) filename = "LQH_V5_music.mp3";
        filename = filename.replace("/", "_").replace("\\", "_");
        if (Build.VERSION.SDK_INT < 29 && checkSelfPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.WRITE_EXTERNAL_STORAGE}, REQ_STORAGE);
            Toast.makeText(this, "Bật quyền bộ nhớ rồi bấm tải lại", Toast.LENGTH_LONG).show();
            return;
        }
        try {
            DownloadManager.Request req = new DownloadManager.Request(Uri.parse(url));
            req.setTitle("LQH V5 Music Download");
            req.setDescription(filename);
            req.setNotificationVisibility(DownloadManager.Request.VISIBILITY_VISIBLE_NOTIFY_COMPLETED);
            req.setDestinationInExternalPublicDir(Environment.DIRECTORY_DOWNLOADS, filename);
            DownloadManager dm = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
            dm.enqueue(req);
            Toast.makeText(this, "Đang tải vào Downloads: " + filename, Toast.LENGTH_LONG).show();
        } catch (Exception e) {
            Toast.makeText(this, "Không tải được: " + e.getMessage(), Toast.LENGTH_LONG).show();
        }
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setLineSpacing(0, 1.08f);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private EditText edit(String hint) {
        EditText e = new EditText(this);
        e.setHint(hint);
        e.setSingleLine(true);
        e.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_VARIATION_URI);
        e.setTextColor(Color.WHITE);
        e.setHintTextColor(Color.rgb(100, 160, 150));
        e.setTypeface(Typeface.MONOSPACE);
        e.setPadding(dp(12), 0, dp(12), 0);
        e.setBackground(box(Color.rgb(8, 10, 18), Color.rgb(0, 120, 120), 16, 1));
        return e;
    }

    private Button bigButton(String s, int c1, int c2) {
        Button b = new Button(this);
        b.setText(s);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setAllCaps(false);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        gd.setCornerRadius(dp(18));
        gd.setStroke(dp(2), Color.WHITE);
        b.setBackground(gd);
        return b;
    }

    private Button modeButton(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setBackground(box(Color.rgb(9, 9, 18), color, 16, 1));
        return b;
    }

    private void markModeButton(Button b, boolean on, int color) {
        if (b == null) return;
        b.setBackground(on ? gradient(color, Color.WHITE) : box(Color.rgb(9, 9, 18), color, 16, 1));
    }

    private Button darkButton(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextColor(Color.WHITE);
        b.setTextSize(14);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setBackground(box(Color.rgb(8, 8, 18), color, 18, 2));
        return b;
    }

    private LinearLayout card(int fill, int stroke, int radius, int strokeWidth) {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        l.setBackground(box(fill, stroke, radius, strokeWidth));
        return l;
    }

    private GradientDrawable gradient(int c1, int c2) {
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.LEFT_RIGHT, new int[]{c1, c2});
        gd.setCornerRadius(dp(18));
        gd.setStroke(dp(2), Color.WHITE);
        return gd;
    }

    private GradientDrawable box(int fill, int stroke, int radius, int strokeWidth) {
        GradientDrawable gd = new GradientDrawable();
        gd.setColor(fill);
        gd.setCornerRadius(dp(radius));
        gd.setStroke(dp(strokeWidth), stroke);
        return gd;
    }

    private void addChip(LinearLayout parent, String s) {
        TextView chip = text(s, 12, Color.WHITE, true);
        chip.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        chip.setGravity(Gravity.CENTER);
        chip.setPadding(dp(12), dp(8), dp(12), dp(8));
        chip.setBackground(box(Color.rgb(8, 8, 18), Color.rgb(0, 255, 120), 18, 1));
        parent.addView(chip, lp(-2, -2, 0, 0, 8, 0));
    }

    private String randomBits(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(random.nextBoolean() ? '1' : '0');
        return sb.toString();
    }

    private String randomHex(int n) {
        String h = "0123456789ABCDEF";
        StringBuilder sb = new StringBuilder("0x");
        for (int i = 0; i < n; i++) sb.append(h.charAt(random.nextInt(h.length())));
        return sb.toString();
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }
}
