package com.lqh.gamegeniex;

import android.app.ActivityManager;
import android.app.Service;
import android.content.Intent;
import android.content.IntentFilter;
import android.graphics.Color;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.provider.Settings;
import android.view.Gravity;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;
import java.util.Random;

public class HudOverlayService extends Service {
    private WindowManager wm;
    private View bubble;
    private LinearLayout panel;
    private WindowManager.LayoutParams bubbleLp, panelLp;
    private TextView titleText, modeText, gameText, ramText, battText, netText, pulseText, fpsText;
    private final Handler handler = new Handler();
    private final Random random = new Random();
    private String gameName = "Chưa chọn game";
    private String mode = "MID";
    private boolean glitchFx = true;

    private final Runnable tick = new Runnable() {
        @Override public void run() {
            updateStats();
            animateGlitch();
            handler.postDelayed(this, delayByMode());
        }
    };

    @Override public IBinder onBind(Intent intent) { return null; }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (intent != null) {
            if (intent.hasExtra("game_name")) gameName = intent.getStringExtra("game_name");
            if (intent.hasExtra("mode")) mode = intent.getStringExtra("mode");
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Chưa có quyền hiển thị trên ứng dụng khác", Toast.LENGTH_LONG).show();
            stopSelf();
            return START_NOT_STICKY;
        }
        showHud();
        return START_STICKY;
    }

    private void showHud() {
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        if (bubble == null) createBubble();
        if (panel == null) createPanel();
        try { if (bubble.getParent() == null) wm.addView(bubble, bubbleLp); } catch (Exception ignored) {}
        try { if (panel.getParent() == null) wm.addView(panel, panelLp); } catch (Exception ignored) {}
        panel.setVisibility(View.VISIBLE);
        applyModeLook();
        updateStats();
        handler.removeCallbacks(tick);
        handler.post(tick);
    }

    private void createBubble() {
        TextView b = new TextView(this);
        b.setText("LQH\nV5");
        b.setTextSize(15);
        b.setTextColor(Color.WHITE);
        b.setGravity(Gravity.CENTER);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setShadowLayer(14, 0, 0, Color.rgb(0, 255, 120));
        b.setBackground(bubbleBg());
        if (Build.VERSION.SDK_INT >= 21) b.setElevation(dp(18));
        bubble = b;

        bubbleLp = params(dp(74), dp(74));
        bubbleLp.gravity = Gravity.TOP | Gravity.START;
        bubbleLp.x = dp(12);
        bubbleLp.y = dp(120);
        bubble.setOnClickListener(v -> togglePanel());
        bubble.setOnTouchListener(new DragTouch(bubbleLp));
    }

    private void createPanel() {
        panel = new LinearLayout(this);
        panel.setOrientation(LinearLayout.VERTICAL);
        panel.setPadding(dp(12), dp(12), dp(12), dp(12));
        panel.setBackground(panelBg(Color.rgb(0, 255, 120)));
        if (Build.VERSION.SDK_INT >= 21) panel.setElevation(dp(22));

        titleText = text("LQH // GAME GENIE X", 18, Color.WHITE, true);
        titleText.setGravity(Gravity.CENTER);
        titleText.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        titleText.setShadowLayer(16, 0, 0, Color.rgb(0, 255, 120));
        panel.addView(titleText, lp(-1, -2, 0, 0, 0, 2));

        TextView version = text("V5 GLITCH HUD • NO ROOT", 11, Color.rgb(0, 255, 120), true);
        version.setGravity(Gravity.CENTER);
        version.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panel.addView(version, lp(-1, -2, 0, 0, 0, 8));

        pulseText = stat("TRACE", "BOOTING 0xLQH", Color.rgb(0, 255, 120));
        panel.addView(pulseText, lp(-1, -2, 0, 0, 0, 7));
        gameText = stat("🎮 GAME", gameName, Color.rgb(255, 238, 88));
        panel.addView(gameText, lp(-1, -2, 0, 0, 0, 7));
        modeText = stat("⚡ MODE", modeName(), accentColor(), Color.WHITE);
        panel.addView(modeText, lp(-1, -2, 0, 0, 0, 7));
        fpsText = stat("FPS HUD", "SIM: -- / FX: ON", Color.rgb(0, 255, 255));
        panel.addView(fpsText, lp(-1, -2, 0, 0, 0, 7));
        ramText = stat("RAM", "--", Color.WHITE);
        panel.addView(ramText, lp(-1, -2, 0, 0, 0, 7));
        battText = stat("BATTERY", "--", Color.WHITE);
        panel.addView(battText, lp(-1, -2, 0, 0, 0, 7));
        netText = stat("NETWORK", "--", Color.WHITE);
        panel.addView(netText, lp(-1, -2, 0, 0, 0, 10));

        TextView label = text("CHỌN MODE NGAY TRONG GAME", 12, Color.rgb(0, 255, 120), true);
        label.setGravity(Gravity.CENTER);
        label.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        panel.addView(label, lp(-1, -2, 0, 0, 0, 7));

        LinearLayout modes = new LinearLayout(this);
        modes.setOrientation(LinearLayout.VERTICAL);
        panel.addView(modes, lp(-1, -2, 0, 0, 0, 8));
        Button eco = btn("TIẾT KIỆM", Color.rgb(0, 200, 90));
        eco.setOnClickListener(v -> setMode("ECO"));
        modes.addView(eco, lp(-1, dp(42), 0, 0, 0, 6));
        Button mid = btn("TRUNG BÌNH", Color.rgb(120, 80, 255));
        mid.setOnClickListener(v -> setMode("MID"));
        modes.addView(mid, lp(-1, dp(42), 0, 0, 0, 6));
        Button x = btn("NÂNG CAO GIỰT FX", Color.rgb(255, 23, 68));
        x.setOnClickListener(v -> setMode("X"));
        modes.addView(x, lp(-1, dp(42), 0, 0, 0, 0));

        LinearLayout row1 = new LinearLayout(this);
        row1.setOrientation(LinearLayout.HORIZONTAL);
        panel.addView(row1, lp(-1, dp(46), 0, 0, 0, 8));
        Button fx = btn("GIỰT FX", Color.rgb(0, 255, 120));
        fx.setOnClickListener(v -> {
            glitchFx = !glitchFx;
            Toast.makeText(this, glitchFx ? "Glitch FX bật" : "Glitch FX tắt", Toast.LENGTH_SHORT).show();
            updateStats();
        });
        row1.addView(fx, lp(0, -1, 0, 0, 5, 0, 1));
        Button hide = btn("ẨN", Color.rgb(120, 80, 255));
        hide.setOnClickListener(v -> panel.setVisibility(View.GONE));
        row1.addView(hide, lp(0, -1, 5, 0, 0, 0, 1));

        LinearLayout row2 = new LinearLayout(this);
        row2.setOrientation(LinearLayout.HORIZONTAL);
        panel.addView(row2, lp(-1, dp(46), 0, 0, 0, 0));
        Button app = btn("APP", Color.rgb(0, 255, 255));
        app.setOnClickListener(v -> openApp());
        row2.addView(app, lp(0, -1, 0, 0, 5, 0, 1));
        Button close = btn("TẮT HUD", Color.rgb(255, 55, 55));
        close.setOnClickListener(v -> stopSelf());
        row2.addView(close, lp(0, -1, 5, 0, 0, 0, 1));

        panel.setOnTouchListener(new DragTouchPanel());
        panelLp = params(dp(338), WindowManager.LayoutParams.WRAP_CONTENT);
        panelLp.gravity = Gravity.TOP | Gravity.START;
        panelLp.x = dp(18);
        panelLp.y = dp(160);
    }

    private void setMode(String m) {
        mode = m;
        applyModeLook();
        updateStats();
        Toast.makeText(this, "Mode: " + modeName(), Toast.LENGTH_SHORT).show();
    }

    private void applyModeLook() {
        int c = accentColor();
        if (panel != null) panel.setBackground(panelBg(c));
        if (bubble != null) bubble.setBackground(bubbleBg());
        if (titleText != null) titleText.setShadowLayer("X".equals(mode) ? 24 : 14, 0, 0, c);
        if (modeText != null) modeText.setBackground(box(Color.rgb(9, 9, 18), c, 16, 2));
        if (panelLp != null) {
            if ("X".equals(mode)) panelLp.flags |= WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            else panelLp.flags &= ~WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON;
            try { wm.updateViewLayout(panel, panelLp); } catch (Exception ignored) {}
        }
    }

    private int delayByMode() {
        if ("ECO".equals(mode)) return 1450;
        if ("X".equals(mode)) return 430;
        return 850;
    }

    private String modeName() {
        if ("ECO".equals(mode)) return "TIẾT KIỆM";
        if ("X".equals(mode)) return "NÂNG CAO GIỰT FX";
        return "TRUNG BÌNH";
    }

    private int accentColor() {
        if ("ECO".equals(mode)) return Color.rgb(0, 220, 90);
        if ("X".equals(mode)) return Color.rgb(255, 23, 68);
        return Color.rgb(120, 80, 255);
    }

    private void animateGlitch() {
        if (!glitchFx) return;
        int c = accentColor();
        if (titleText != null) {
            String[] names = {"LQH // GAME GENIE X", "LQH >_ GENIE V5", "0xLQH :: XHUD", "GAME GENIE X // V5"};
            titleText.setText(names[random.nextInt(names.length)]);
            titleText.setTextColor(random.nextInt(5) == 0 ? Color.rgb(0, 255, 255) : Color.WHITE);
            titleText.setShadowLayer(14 + random.nextInt(12), random.nextInt(3) - 1, random.nextInt(3) - 1, c);
        }
        if (pulseText != null) pulseText.setText("TRACE\n" + randomHex(4) + " :: " + randomBits(18));
        if (bubble instanceof TextView) {
            String[] b = {"LQH\nV5", "0x\nLQH", "X\nHUD", "V5\nFX"};
            ((TextView) bubble).setText(b[random.nextInt(b.length)]);
        }
    }

    private TextView stat(String k, String v, int accent) { return stat(k, v, accent, Color.WHITE); }

    private TextView stat(String k, String v, int accent, int textColor) {
        TextView t = text(k + "\n" + v, 12, textColor, true);
        t.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        t.setPadding(dp(10), dp(7), dp(10), dp(7));
        t.setBackground(box(Color.rgb(8, 8, 18), accent, 16, 1));
        return t;
    }

    private void updateStats() {
        if (gameText != null) gameText.setText("🎮 GAME\n" + gameName);
        if (modeText != null) modeText.setText("⚡ MODE\n" + modeName());
        if (fpsText != null) {
            int sim = "ECO".equals(mode) ? 45 + random.nextInt(16) : ("X".equals(mode) ? 90 + random.nextInt(31) : 60 + random.nextInt(16));
            fpsText.setText("FPS HUD\nSIM: " + sim + " / FX: " + (glitchFx ? "ON" : "OFF"));
        }

        try {
            ActivityManager.MemoryInfo mi = new ActivityManager.MemoryInfo();
            ActivityManager am = (ActivityManager) getSystemService(ACTIVITY_SERVICE);
            am.getMemoryInfo(mi);
            long avail = mi.availMem / (1024L * 1024L);
            long total = mi.totalMem / (1024L * 1024L);
            if (ramText != null) ramText.setText(String.format(Locale.US, "RAM\nFREE %d MB / TOTAL %d MB", avail, total));
        } catch (Exception ignored) {}

        try {
            IntentFilter ifilter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
            Intent battery = registerReceiver(null, ifilter);
            int level = battery != null ? battery.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) : -1;
            int scale = battery != null ? battery.getIntExtra(BatteryManager.EXTRA_SCALE, -1) : -1;
            int pct = level >= 0 && scale > 0 ? (int)(level * 100f / scale) : -1;
            if (battText != null) battText.setText("BATTERY\n" + (pct >= 0 ? pct + "%" : "--"));
        } catch (Exception ignored) {}

        try {
            ConnectivityManager cm = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            NetworkInfo ni = cm != null ? cm.getActiveNetworkInfo() : null;
            String network = ni != null && ni.isConnected() ? ni.getTypeName() + " ONLINE" : "OFFLINE";
            if (netText != null) netText.setText("NETWORK\n" + network);
        } catch (Exception ignored) {}
    }

    private void togglePanel() {
        if (panel == null) return;
        panel.setVisibility(panel.getVisibility() == View.VISIBLE ? View.GONE : View.VISIBLE);
    }

    private void openApp() {
        Intent i = new Intent(this, MainActivity.class);
        i.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        startActivity(i);
    }

    private WindowManager.LayoutParams params(int w, int h) {
        int type = Build.VERSION.SDK_INT >= 26 ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY : WindowManager.LayoutParams.TYPE_PHONE;
        return new WindowManager.LayoutParams(w, h, type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                PixelFormat.TRANSLUCENT);
    }

    private class DragTouch implements View.OnTouchListener {
        private final WindowManager.LayoutParams lp;
        private int startX, startY;
        private float downX, downY;
        private long downTime;
        DragTouch(WindowManager.LayoutParams lp) { this.lp = lp; }
        @Override public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = lp.x; startY = lp.y; downX = e.getRawX(); downY = e.getRawY(); downTime = System.currentTimeMillis(); return true;
                case MotionEvent.ACTION_MOVE:
                    lp.x = startX + (int)(e.getRawX() - downX);
                    lp.y = startY + (int)(e.getRawY() - downY);
                    try { wm.updateViewLayout(v, lp); } catch (Exception ignored) {}
                    return true;
                case MotionEvent.ACTION_UP:
                    if (Math.abs(e.getRawX() - downX) < dp(7) && Math.abs(e.getRawY() - downY) < dp(7) && System.currentTimeMillis() - downTime < 280) v.performClick();
                    return true;
            }
            return false;
        }
    }

    private class DragTouchPanel implements View.OnTouchListener {
        private int startX, startY;
        private float downX, downY;
        @Override public boolean onTouch(View v, MotionEvent e) {
            switch (e.getAction()) {
                case MotionEvent.ACTION_DOWN:
                    startX = panelLp.x; startY = panelLp.y; downX = e.getRawX(); downY = e.getRawY(); return true;
                case MotionEvent.ACTION_MOVE:
                    panelLp.x = startX + (int)(e.getRawX() - downX);
                    panelLp.y = startY + (int)(e.getRawY() - downY);
                    try { wm.updateViewLayout(panel, panelLp); } catch (Exception ignored) {}
                    return true;
            }
            return false;
        }
    }

    private TextView text(String s, int sp, int color, boolean bold) {
        TextView v = new TextView(this);
        v.setText(s);
        v.setTextSize(sp);
        v.setTextColor(color);
        v.setLineSpacing(0, 1.05f);
        if (bold) v.setTypeface(Typeface.DEFAULT_BOLD);
        return v;
    }

    private Button btn(String s, int color) {
        Button b = new Button(this);
        b.setText(s);
        b.setAllCaps(false);
        b.setTextSize(11);
        b.setTextColor(Color.WHITE);
        b.setTypeface(Typeface.MONOSPACE, Typeface.BOLD);
        b.setBackground(box(Color.rgb(9, 9, 18), color, 15, 1));
        return b;
    }

    private GradientDrawable panelBg(int stroke) {
        GradientDrawable bg = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(0, 0, 0), Color.rgb(8, 6, 18), Color.rgb(0, 20, 15)});
        bg.setCornerRadius(dp(22));
        bg.setStroke(dp(2), stroke);
        return bg;
    }

    private GradientDrawable bubbleBg() {
        int c = accentColor();
        GradientDrawable gd = new GradientDrawable(GradientDrawable.Orientation.TL_BR,
                new int[]{Color.rgb(0, 0, 0), c, Color.rgb(0, 255, 255)});
        gd.setShape(GradientDrawable.OVAL);
        gd.setStroke(dp(2), Color.WHITE);
        return gd;
    }

    private GradientDrawable box(int fill, int stroke, int radius, int strokeWidth) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(fill);
        g.setCornerRadius(dp(radius));
        g.setStroke(dp(strokeWidth), stroke);
        return g;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int l, int t, int r, int b, float weight) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h, weight);
        p.setMargins(dp(l), dp(t), dp(r), dp(b));
        return p;
    }

    private String randomBits(int n) {
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < n; i++) sb.append(random.nextBoolean() ? '1' : '0');
        return sb.toString();
    }

    private String randomHex(int n) {
        String h = "0123456789ABCDEF";
        StringBuilder sb = new StringBuilder("0x");
        for (int i = 0; i < n; i++) sb.append(h.charAt(random.nextInt(h.length())));
        return sb.toString();
    }

    private int dp(int v) { return (int) (v * getResources().getDisplayMetrics().density + 0.5f); }

    @Override public void onDestroy() {
        handler.removeCallbacks(tick);
        try { if (bubble != null) wm.removeView(bubble); } catch (Exception ignored) {}
        try { if (panel != null) wm.removeView(panel); } catch (Exception ignored) {}
        bubble = null; panel = null;
        super.onDestroy();
    }
}
