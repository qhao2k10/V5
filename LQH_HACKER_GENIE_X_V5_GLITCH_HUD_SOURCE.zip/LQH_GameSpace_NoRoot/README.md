# LQH Genie X V5 - Glitch HUD

Bản V5 đổi giao diện sang cyber/hacker neon, có HUD nổi trong game và 3 chế độ:

- TIẾT KIỆM: cập nhật chậm hơn, nhẹ pin hơn.
- TRUNG BÌNH: cân bằng.
- NÂNG CAO GIỰT FX: hiệu ứng glitch nhanh, HUD sáng hơn.

## Check đúng bản

Mở app phải thấy:

- LQH HACKER GENIE X • V5 GLITCH HUD
- 3 nút mode: TIẾT KIỆM / TRUNG BÌNH / NÂNG CAO GIỰT FX
- Nút TEST MENU NỔI V5 NGAY

Không thấy các chữ này là vẫn đang cài nhầm bản cũ.

## Dùng HUD

1. Mở app.
2. Chọn mode.
3. Bấm TEST MENU NỔI V5 NGAY để xin quyền overlay.
4. Bật quyền Hiển thị trên ứng dụng khác.
5. Quay lại app và bấm TEST lại.
6. Chọn game rồi bấm BẬT HUD GLITCH + VÀO GAME.

Lưu ý: no root/no adb/no Shizuku thì đây là HUD overlay hợp lệ, không phải hack/cheat game.
